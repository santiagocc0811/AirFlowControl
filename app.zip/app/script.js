document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('registration-screen').style.display = 'none';
    document.getElementById('welcome-screen').style.display = 'block';
});

document.getElementById('location-btn').addEventListener('click', function() {
    document.getElementById('location-screen').style.display = 'block';
    document.getElementById('welcome-screen').style.display = 'none';
});

document.getElementById('lab1-btn').addEventListener('click', function() {
    showControlScreen();
});

document.getElementById('lab2-btn').addEventListener('click', function() {
    showControlScreen();
});

function showControlScreen() {
    document.getElementById('location-screen').style.display = 'none';
    document.getElementById('control-screen').style.display = 'block';
}

let temperature = 24;

document.getElementById('power').addEventListener('click', function() {
    alert('Encender/Apagar');
});

document.getElementById('temp-down').addEventListener('click', function() {
    if (temperature > 0) {
        temperature--;
        document.getElementById('temperature-display').innerText = temperature + '°C';
    }
});

document.getElementById('temp-up').addEventListener('click', function() {
    if (temperature < 30) {
        temperature++;
        document.getElementById('temperature-display').innerText = temperature + '°C';
    }
});

document.getElementById('mode').addEventListener('click', function() {
    let students = prompt('¿Cuántos alumnos hay?');
    if (students > 30) {
        alert('Advertencia: El número de alumnos es mayor a 30.');
    }
});
